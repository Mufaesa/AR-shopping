public class SoftIce implements IceCream{


    public String getDescription() {

        return "Regular soft ice";

    }

    public double getCost() {

        return 0.70;

    }
}
