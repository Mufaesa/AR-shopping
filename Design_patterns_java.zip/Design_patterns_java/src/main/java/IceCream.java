public interface IceCream {

    public String getDescription();

    public double getCost();

}
