package com.example.tfjvr.advanced_mobile;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RememberActivity extends AppCompatActivity {
    private TextView textView;
    private EditText editText;
    private Button applyTextButton;
    private Button saveButton;
    private Switch switch1;
    private ListView listView;

    //ArrayList<String> arrayList = new ArrayList<>();
    //ArrayAdapter<String> todoAdapter;

    public static final String SHARED_PREFS = "SharedPrefs";
    public static final String TEXT = "Text";
    public static final String SWITCH1 = "switch1";

    private String text;
    private Boolean switchOnOff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remember);

        textView = (TextView) findViewById(R.id.textview);
        editText = (EditText) findViewById(R.id.edittext);
        applyTextButton = (Button) findViewById(R.id.apply_text_button);
        saveButton = (Button) findViewById(R.id.save_button);
        switch1 = (Switch) findViewById(R.id.switch1);
        //listView = (ListView) findViewById(R.id.todoListView);
//
//        for(String all_data : names ){
//            arrayList.add(all_data);
//        }

        //todoAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayList);
        //listView.setAdapter(todoAdapter);
        //registerForContextMenu(listView);
        //listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Toast.makeText(getApplicationContext(), names[i], Toast.LENGTH_SHORT).show();
//            }
//        });
//
        applyTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText(editText.getText().toString());
            }
        });
//
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });
//
        loadData();
        updateViews();
    }

//    @Override
//    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
//        super.onCreateContextMenu(menu, v, menuInfo);
//        MenuInflater menuInflater = getMenuInflater();
//        menuInflater.inflate(R.menu.context_menu_file, menu);
//    }
//
//    @Override
//    public boolean onContextItemSelected(MenuItem item) {
//        AdapterView.AdapterContextMenuInfo obj = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
//
//        switch (item.getItemId()){
//            case R.id.Delete:
//                arrayList.remove(obj.position);
//                todoAdapter.notifyDataSetChanged();
//                break;
//        }
//
//        return super.onContextItemSelected(item);
//    }

    private void saveData() {
                //Call the sharedpreferences
                SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString(TEXT,  textView.getText().toString());
                editor.putBoolean(SWITCH1, switch1.isChecked());

                editor.apply();

                Toast.makeText(this, "Data saved", Toast.LENGTH_SHORT).show();
            }

            public void loadData(){
                SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
                text = sharedPreferences.getString(TEXT, "");
                switchOnOff = sharedPreferences.getBoolean(SWITCH1, false);

            }

            public void updateViews(){
                textView.setText(text);
                switch1.setChecked(switchOnOff);
            }


}
